import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import threading
import keyboard
import os
import ctypes

# Constants for window styles
WS_EX_LAYERED = 0x80000
WS_EX_TRANSPARENT = 0x20
LWA_COLORKEY = 0x00000001

class RecordingIndicatorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Recording Indicator")
        self.geometry("800x600")
        self.resizable(True, True)

        # Variables to store user inputs
        self.key_bindings = {}
        self.image_paths = {}
        self.filename_vars = {}  # Added to store filename display variables
        self.position = tk.StringVar(value="top-left")
        self.custom_position = (0, 0)
        self.overlay_window = None

        self.create_widgets()

    def create_widgets(self):
        # Heading
        tk.Label(self, text="Recording Indicator", font=("Helvetica", 24)).pack(pady=10)

        # Description
        description_text = (
            "This app is a recording indicator app for any type of recording software like OBS, Bandicam etc. "
            "It displays an indicator as overlay on top of screen when you are recording game in full screen or window mode."
        )
        tk.Label(self, text=description_text, wraplength=750, justify="left").pack(pady=10)

        # Function keys and image uploads
        functions = [
            "Start Streaming", "Stop Streaming", "Start Recording",
            "Stop Recording", "Pause Recording", "Unpause Recording"
        ]
        for func in functions:
            frame = tk.Frame(self)
            frame.pack(fill="x", padx=20, pady=5)

            # Key binding input
            tk.Label(frame, text=f"{func} Key:", width=20, anchor="w").pack(side="left")
            key_var = tk.StringVar()
            tk.Entry(frame, textvariable=key_var, width=10).pack(side="left")
            self.key_bindings[func] = key_var

            # Image upload
            tk.Label(frame, text=f"{func} Image:", width=15, anchor="w").pack(side="left")
            img_var = tk.StringVar()
            tk.Button(frame, text="Browse", command=lambda f=func, v=img_var: self.browse_image(f, v)).pack(side="left")
            self.image_paths[func] = img_var

            # Filename display (truncated to 12 characters)
            filename_var = tk.StringVar()
            tk.Label(frame, textvariable=filename_var, width=15, anchor="w").pack(side="left")
            self.filename_vars[func] = filename_var

        # Indicator position
        position_frame = tk.Frame(self)
        position_frame.pack(pady=10)
        tk.Label(position_frame, text="Indicator Position:", width=20, anchor="w").pack(side="left")
        positions = ["top-left", "top-right", "bottom-left", "bottom-right", "custom"]
        for pos in positions:
            tk.Radiobutton(position_frame, text=pos.replace("-", " ").title(),
                           variable=self.position, value=pos).pack(side="left")

        # Custom position instruction
        tk.Label(self, text="For custom position, double-click on the screen where you want the indicator.", fg="blue").pack()

        # Start and Stop buttons
        button_frame = tk.Frame(self)
        button_frame.pack(pady=20)
        tk.Button(button_frame, text="Start App", command=self.start_app).pack(side="left", padx=10)
        tk.Button(button_frame, text="Stop App", command=self.stop_app).pack(side="left", padx=10)

        # Developer name at the bottom right
        dev_frame = tk.Frame(self)
        dev_frame.pack(side="bottom", fill="x")
        tk.Label(dev_frame, text="Created with love by Amit Shashi", anchor="e").pack(side="right", padx=10, pady=5)

        # Bind double-click event for custom position
        self.bind("<Double-Button-1>", self.set_custom_position)

    def browse_image(self, function_name, var):
        path = filedialog.askopenfilename(filetypes=[("PNG files", "*.png")])
        if path:
            var.set(path)
            # Get the filename from path and truncate it
            filename = os.path.basename(path)
            if len(filename) > 12:
                filename = filename[:12] + "..."
            # Update the filename display
            self.filename_vars[function_name].set(filename)

    def set_custom_position(self, event):
        if self.position.get() == "custom":
            self.custom_position = (event.x_root, event.y_root)
            messagebox.showinfo("Custom Position Set", f"Indicator will be shown at {self.custom_position}")

    def start_app(self):
        # Validate inputs
        for func, key_var in self.key_bindings.items():
            key = key_var.get()
            image = self.image_paths[func].get()
            if not key or not image:
                messagebox.showerror("Input Error", f"Please set both key and image for '{func}'.")
                return

        # Set up key listeners
        for func, key_var in self.key_bindings.items():
            key = key_var.get()
            keyboard.add_hotkey(key, self.show_indicator, args=(func,))
        messagebox.showinfo("App Started", "Recording Indicator is now running.")

    def stop_app(self):
        keyboard.unhook_all()
        self.destroy_overlay()
        messagebox.showinfo("App Stopped", "Recording Indicator has been stopped.")

    def show_indicator(self, func):
        image_path = self.image_paths[func].get()
        if image_path:
            self.display_overlay(image_path)

    def display_overlay(self, image_path):
        self.destroy_overlay()
        self.overlay_window = tk.Toplevel()
        self.overlay_window.overrideredirect(True)
        self.overlay_window.attributes("-topmost", True)
        self.overlay_window.attributes("-transparentcolor", "white")

        # Load image
        image = Image.open(image_path)
        photo = ImageTk.PhotoImage(image)
        tk.Label(self.overlay_window, image=photo, bg="white").pack()

        # Position overlay
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        img_width, img_height = image.size

        positions = {
            "top-left": (0, 0),
            "top-right": (screen_width - img_width, 0),
            "bottom-left": (0, screen_height - img_height),
            "bottom-right": (screen_width - img_width, screen_height - img_height),
            "custom": self.custom_position
        }
        x, y = positions.get(self.position.get(), (0, 0))
        self.overlay_window.geometry(f"{img_width}x{img_height}+{int(x)}+{int(y)}")

        # Keep a reference to the image
        self.overlay_window.image = photo

        # Make the overlay window click-through
        hwnd = ctypes.windll.user32.GetParent(self.overlay_window.winfo_id())
        styles = ctypes.windll.user32.GetWindowLongPtrW(hwnd, -20)
        ctypes.windll.user32.SetWindowLongPtrW(hwnd, -20, styles | WS_EX_LAYERED | WS_EX_TRANSPARENT)
        ctypes.windll.user32.SetLayeredWindowAttributes(hwnd, 0x00FFFFFF, 0, LWA_COLORKEY)

    def destroy_overlay(self):
        if self.overlay_window:
            self.overlay_window.destroy()
            self.overlay_window = None

if __name__ == "__main__":
    app = RecordingIndicatorApp()
    app.mainloop()
